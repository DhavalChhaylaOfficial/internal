const bookModule = angular.module('bookApp', []);

// Controller for managing books
bookModule.controller('bookCtrl', function ($scope, $http) {
    $scope.books = [];
    $scope.newBook = {
        coverPhoto: null, // Include coverPhoto for uploads
        bookID: generateBookID() // Automatically generate Book ID
    };
    $scope.editBookID = null;
    $scope.msg = '';
    $scope.sort = 'bookName';

    // Function to generate a unique Book ID
    function generateBookID() {
        return 'BID-' + Date.now() + '-' + Math.floor(Math.random() * 1000); // Example: BID-1630549386000-123
    }

    // Function to fetch book data
    $scope.getBooks = function () {
        $http.get('/api/getBookDetails').then(function (response) {
            $scope.books = response.data;
            $scope.msg = $scope.books.length === 0 ? 'No books found' : '';
        }, function (error) {
            $scope.msg = 'Error fetching books';
            console.error(error);
        });
    };

    // Function to add a new book
    $scope.addBook = function () {
        const formData = new FormData();
        formData.append('bookID', $scope.newBook.bookID); // Book ID is generated and sent
        formData.append('bookName', $scope.newBook.bookName);
        formData.append('author', $scope.newBook.author);
        formData.append('price', $scope.newBook.price);
        formData.append('isbn', $scope.newBook.isbn);
        if ($scope.newBook.coverPhoto) {
            formData.append('coverPhoto', $scope.newBook.coverPhoto); // Handle file upload
        }

        // Check for existing Book ID
        const existingBook = $scope.books.find(item => item.bookID === $scope.newBook.bookID);
        if (existingBook) {
            $scope.msg = 'Book ID already exists. Please enter a unique Book ID.';
            return;
        }

        $http.post('/api/addBook', formData, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        }).then(function (response) {
            $scope.msg = response.data.message;
            $scope.getBooks();
            // Reset the newBook object and generate a new Book ID
            $scope.newBook = { coverPhoto: null, bookID: generateBookID() };
        }, function (error) {
            $scope.msg = 'Error adding book';
            console.error(error);
        });
    };

    // Function to delete a book
    $scope.deleteBook = function (bookID) {
        $http.delete(`/api/deleteBook/${bookID}`).then(function (response) {
            $scope.msg = 'Book deleted';
            $scope.getBooks(); // Refresh the book list
        }, function (error) {
            $scope.msg = 'Error deleting book';
            console.error(error);
        });
    };

    // Function to initiate edit mode
    $scope.editBook = function (bookID) {
        $scope.editBookID = bookID; // Set the currently editing book ID
    };

    // Function to save the edited book
    $scope.saveBook = function (item) {
        $http.put(`/api/editBook/${item.bookID}`, item).then(function (response) {
            $scope.msg = 'Book updated';
            $scope.editBookID = null; // Clear the edit ID after saving
            $scope.getBooks(); // Refresh the book list
        }, function (error) {
            $scope.msg = 'Error updating book';
            console.error(error);
        });
    };

    // Initial fetch of book list
    $scope.getBooks();
});
