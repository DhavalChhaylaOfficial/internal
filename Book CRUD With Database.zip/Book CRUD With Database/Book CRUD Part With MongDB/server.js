const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB connection
mongoose.connect('mongodb://localhost/book_management', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Define a book schema
const bookSchema = new mongoose.Schema({
    bookID: { type: String, required: true, unique: true },
    bookName: { type: String, required: true },
    author: { type: String, required: true },
    price: { type: Number, required: true }, // Field for book price
    isbn: { type: String, required: true } // Field for ISBN
});

const Book = mongoose.model('Book', bookSchema);

// API to get book details
app.get('/api/getBookDetails', async (req, res) => {
    try {
        const books = await Book.find({});
        res.json(books);
    } catch (err) {
        res.status(500).send(err);
    }
});

// API to add a new book
app.post('/api/addBook', async (req, res) => {
    console.log('Request body:', req.body);

    const newBook = new Book({
        bookID: req.body.bookID,
        bookName: req.body.bookName,
        author: req.body.author,
        price: req.body.price,
        isbn: req.body.isbn,
    });

    try {
        await newBook.save();
        res.json({ message: 'Book added successfully' });
    } catch (err) {
        console.error(err);
        if (err.name === 'ValidationError') {
            return res.status(400).json({ message: 'Validation error', errors: err.errors });
        }
        res.status(500).send(err);
    }
});

// API to delete a book
app.delete('/api/deleteBook/:bookID', async (req, res) => {
    try {
        await Book.findOneAndDelete({ bookID: req.params.bookID });
        res.json({ message: 'Book deleted successfully' });
    } catch (err) {
        res.status(500).send(err);
    }
});

// API to update a book
app.put('/api/editBook/:bookID', async (req, res) => {
    const updatedBook = {
        bookName: req.body.bookName,
        author: req.body.author,
        price: req.body.price,
        isbn: req.body.isbn // Update isbn field
    };

    try {
        const book = await Book.findOneAndUpdate({ bookID: req.params.bookID }, updatedBook, { new: true });
        res.json({ message: 'Book updated successfully', book });
    } catch (err) {
        res.status(500).send(err);
    }
});

// Start the server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
