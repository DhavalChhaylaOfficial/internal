const express = require("express");
const app = express();

// middlewares
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const tasks = [
  { taskID: "Task1", taskName: "Check Assignment" },
  { taskID: "Task2", taskName: "Take Attendance" },
  { taskID: "Task3", taskName: "Create Test" },
  { taskID: "Task4", taskName: "Set Paper" },
];

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

// API to read task Data
app.get("/api/getTaskDetails", (req, res) => {
  res.json(tasks);
});

// API to add the task data
app.post("/api/addTask", (req, res) => {
  const newTask = req.body;
  tasks.push(newTask);
  res.status(201).json({ message: "Task Added" });
});

// API to delete task
app.delete("/api/deleteTask/:id", (req, res) => {
  const taskid = req.params.id;
  const index = tasks.findIndex((tasks) => tasks.taskID == taskid);

  if (index !== -1) {
    tasks.splice(index, 1);
    res.json({ message: "Task Deleted" });
  } else {
    res.status(404).json({ message: "Task Not Found" });
  }
});

// API to Edit Task
app.put("/api/editTask/:id", (req, res) => {
  const id = req.params.id;
  const updatedTask = req.body;
  const index = tasks.findIndex((tasks) => tasks.taskID === id);
  if (index != 0) {
    tasks[index] = updatedTask;
    res.json({ message: "Item Updated" });
  }
});

app.listen(1000, () => {
  console.log("Server is running on port 1000");
  console.log("http://localhost:1000");
});
