const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect("mongodb://localhost:27017/23mca028");

const conn = mongoose.connection;
conn.on('connected', () => {
    console.log("Connected to MongoDB");
});
const userSchema = mongoose.Schema({
    userID: String,
    password: String,
    role: String,
    photoURL: String // New field for user photo URL
});

const studentSchema = mongoose.Schema({
    studID: String,
    studName: String,
    course: String,
    semester: String,
    status: String,
    photoURL: String // New field for student photo URL
});

const User = mongoose.model('User', userSchema);
const Student = mongoose.model('Student', studentSchema);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public'));
});

app.get('/api/users', (req, res) => {
    User.find().then((data) => {
        res.json(data);
    }).catch(err => res.status(500).send(err));
});

app.get('/api/students', (req, res) => {
    Student.find().then((data) => {
        res.json(data);
    }).catch(err => res.status(500).send(err));
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    User.findOne({ userID: username, password: password })
        .then(user => {
            if (user) {
                if (user.role === 'student') {
                    Student.findOne({ studID: user.userID }) 
                        .then(student => {
                            if (student) {
                                res.json({ success: true, role: user.role, studentDetails: student });
                            } else {
                                res.status(404).json({ success: false, message: 'Student not found' });
                            }
                        });
                } else {

                    res.json({ success: true, role: user.role });
                }
            } else {
                res.status(401).json({ success: false, message: 'Invalid credentials' });
            }
        })
        .catch(err => res.status(500).send(err));
});

// API to add a student
app.post('/api/students', (req, res) => {
    const newStudent = new Student(req.body);
    newStudent.save().then((student) => {
        res.json(student);
    }).catch(err => res.status(400).send(err));
});

// API to update a student
app.put('/api/students/:id', (req, res) => {
    Student.findOneAndUpdate({ studID: req.params.id }, req.body, { new: true }).then((updatedStudent) => {
        res.json(updatedStudent);
    }).catch(err => res.status(400).send(err));
});

// API to delete a student
app.delete('/api/students/:id', (req, res) => {
    Student.findOneAndDelete({ studID: req.params.id }).then(() => {
        res.send('Student deleted successfully');
    }).catch(err => res.status(500).send(err));
});

// Start the server

app.listen(3000, () => {
    console.log(`Server is running on port 3000`);
});
