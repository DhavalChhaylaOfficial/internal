var app = angular.module('studApp', []);

app.controller('studCtrl', ['$scope', '$http', function($scope, $http) {
    $scope.loginStatus = false;
    $scope.sort='asc';
    $scope.userRole = '';
    $scope.username = '';
    $scope.password = '';
    $scope.newStudent = {
    studID: '',
    studName: '',
    course: '',
    semester: '',
    status: 'Active',
    photoURL: '' // Default empty

    };
    $scope.loginMessage = '';
    $scope.students = [];
    $scope.studentDetails = null;
    $scope.addstat = 0;
    $scope.selectedStudentID = ''; 
    $scope.isEditing = false;
    
// Check user login
$scope.checkUser = function() {
    $http.post('http://localhost:3000/api/login', { username: $scope.username, password: $scope.password })
        .then(function(response) {
            if (response.data.success) {
                $scope.loginStatus = true;
                $scope.userRole = response.data.role;
                $scope.loginMessage = '';
                if ($scope.userRole === 'student') {
                    $scope.studentDetails = response.data.studentDetails;
                }
                if ($scope.userRole === 'admin') {
                    $scope.fetchStudents();
                }
            }
        })
        .catch(function(error) {
            if (error.status === 401 || error.status === 403) {
                $scope.loginStatus = false;
                $scope.loginMessage = 'Invalid username or password.';
            } else {
                console.error('Error during login:', error);
                $scope.loginStatus = false;
                $scope.loginMessage = 'An error occurred. Please try again later.';
            }
        });
};  
    // Fetch all students for admin
    $scope.fetchStudents = function() {
        $http.get('http://localhost:3000/api/students').then(function(response) {
            $scope.students = response.data;
        }).catch(function(error) {
            console.error('Error fetching students:', error);
        });
    };

    // Search student by ID
    $scope.searchStudentByID = function() {
        $scope.selectedStudent = $scope.students.find(function(student) {
            return student.studID === $scope.selectedStudentID;
        });
    };

    // Fetch student details by ID
    $scope.fetchStudentDetails = function(studentID) {
        $http.get(`http://localhost:3000/api/students/${studentID}`).then(function(response) {
            $scope.studentDetails = response.data;
        }).catch(function(error) {
            console.error('Error fetching student details:', error);
        });
    };

    // Edit student
    $scope.editStudent = function(student) {
        $scope.isEditing = true;
        student.editing = true;
    };
    $scope.saveStudent = function(student) {
        // Validate required fields
        if (!student.studID || !student.studName || !student.course || !student.semester || !student.status) {
            alert("All fields are required.");
            return;        }
    
        // Check for duplicate Student ID
        const duplicate = $scope.students.some(s => s.studID === student.studID && s !== student);
        if (duplicate) {
            alert("The Student ID must be unique.");
            return;
        }
    
        // Proceed only after validations are successful
        $scope.isEditing = false;
        student.editing = false;
    
        // Send update request to the server
        $http.put(`http://localhost:3000/api/students/${student.studID}`, student)
            .then(function(response) {
                // Update the local students array
                const index = $scope.students.findIndex(s => s.studID === student.studID);
                if (index !== -1) {
                    $scope.students[index] = { ...student }; // Update student with fresh data
                }
                alert("Student saved successfully!");
            })
            .catch(function(error) {
                console.error('Error saving student:', error);
            });
    };
    
    
    // Delete student
    $scope.deleteStudent = function(studID) {
        if (confirm('Are you sure you want to delete this student?')) {
            $http.delete(`http://localhost:3000/api/students/${studID}`)
                .then(function(response) {
                    $scope.fetchStudents();
                }).catch(function(error) {
                    console.error('Error deleting student:', error);
                });
        }
    };

    // Add new student
    $scope.addStudent = function() {
        if (!($scope.newStudent.studID && $scope.newStudent.studName && $scope.newStudent.course && $scope.newStudent.semester && $scope.newStudent.status)) {
            alert("All fields are required.");
            return;
        }
        const duplicate = $scope.students.some(s => s.studID === $scope.newStudent.studID);
        if (duplicate) {
            alert("The Student ID must be unique.");
            return;
        }

        $http.post('http://localhost:3000/api/students', $scope.newStudent)
            .then(function(response) {
                $scope.students.push(response.data);
                $scope.newStudent = {};
            alert("Student added successfully!");
            }).catch(function(error) {
                console.error('Error adding student:', error);
            });
    };

    // Logout
    $scope.logout = function() {
        if (confirm('Are you sure you want to logout?')) {
            $scope.loginStatus = false;
            $scope.userRole = '';
            $scope.studentDetails = null;
            $scope.username = '';
            $scope.password = '';
            $scope.loginMessage = '';
        }
     
    };
}]);
