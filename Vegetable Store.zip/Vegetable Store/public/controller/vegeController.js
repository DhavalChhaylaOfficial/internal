const vegModule = angular.module('vegApp', []);
vegModule.controller('vegCtrl', function ($scope) {
    $scope.vegetables = [];
    $scope.newVeg = {};  
    $scope.addStat = 0;
    $scope.editStat = 0;
    $scope.sort = 'vegName';  
    $scope.months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    $scope.years = [2020, 2021, 2022, 2023, 2024, 2025];
    $scope.msg = ''; 

    // Function to fetch vegetable data
    $scope.getVeg = function () {
        $scope.vegetables = [
            { vegID: 'Veg1', vegName: 'Carrot', price: 30, expiryMonth: 'November', expiryYear: '2024', quantity: 2 },
            { vegID: 'Veg2', vegName: 'Tomato', price: 20, expiryMonth: 'December', expiryYear: '2023', quantity: 3 },
        ];
    };

    $scope.isValidExpiry = function (month, year) {
        const currentDate = new Date();
        const expiryDate = new Date(year, $scope.months.indexOf(month), 1);
        return expiryDate > currentDate;
    };

    // Function to add a vegetable
    $scope.addVeg = function () {
        if ($scope.isValidExpiry($scope.newVeg.expiryMonth, $scope.newVeg.expiryYear)) {
            $scope.vegetables.push({
                vegID: $scope.newVeg.vegID,
                vegName: $scope.newVeg.vegName,
                price: $scope.newVeg.price,
                expiryMonth: $scope.newVeg.expiryMonth,
                expiryYear: $scope.newVeg.expiryYear,
                quantity: $scope.newVeg.quantity
            });
            $scope.msg = 'Vegetable Added';
            $scope.newVeg = {}; 
            $scope.addStat = 0; 
        } else {
            $scope.msg = 'Cannot add vegetable with expiry date before ' + currentDate.getMonth() + '/' + currentDate.getFullYear() + '.'; // Error message
        }
    };

    // Function to edit a vegetable
    $scope.editVeg = function (id) {
        $scope.editStat = 1; 
        $scope.id = id; 
    };

    // Function to save edited vegetable details
    $scope.saveVeg = function (id) {
        $scope.editStat = 0; 
        $scope.msg = 'Vegetable Updated'; 
    };

    // Function to delete a vegetable
    $scope.deleteVeg = function (id, expiryMonth, expiryYear) {
        if ($scope.isValidExpiry(expiryMonth, expiryYear)) {
            $scope.vegetables = $scope.vegetables.filter(item => item.vegID !== id);
            $scope.msg = 'Vegetable Deleted'; // Success message
        } else {
            $scope.msg = 'Cannot delete vegetable with expiry date before ' + currentDate.getMonth() + '/' + currentDate.getFullYear() + '.'; // Error message
        }
    };

    // Initial fetch of vegetable data
    $scope.getVeg();
});
