const express = require('express');
const app = express();
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());


// Serve index.html
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// API to fetch vegetable details
app.get('/api/getVegetableDetails', (req, res) => {
    res.json(vegetables);
});

// API to add a new vegetable
app.post('/api/addVegetable', (req, res) => {
    const newVeg = req.body;
    vegetables.push(newVeg);
    res.status(201).json({ message: 'Vegetable added successfully!' });
});

// API to delete a vegetable
app.delete('/api/deleteVegetable/:id', (req, res) => {
    const veg_id = req.params.id;
    const index = vegetables.findIndex(veg => veg.veg_id === veg_id);
    if (index !== -1) {
        vegetables.splice(index, 1);
        res.json({ message: 'Vegetable deleted successfully!' });
    } else {
        res.status(404).json({ message: 'Vegetable not found!' });
    }
});

// Start the server
app.listen(2000, () => {
    console.log('Server is running on port 2000');
});
